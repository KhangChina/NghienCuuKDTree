/*
 * CKdtree.cpp
 *
 *  Created on: 2011-7-24
 *      Author: Tiandao
 */

#include "CKdtree.h"
template <typename T>
CKdtree<T>::CKdtree() {
	// TODO Auto-generated constructor stub

}
template <typename T>
CKdtree<T>::~CKdtree() {
	// TODO Auto-generated destructor stub
}
template <typename T>
void CKdtree<T>::build_kdtree(CVector<T> *ptr_exemplar_set, int cnt)
{
	assert(ptr_exemplar_set);
	assert(cnt > 0);


}

